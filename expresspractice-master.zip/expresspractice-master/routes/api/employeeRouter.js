const express = require('express')
const employeeRouter = express.Router()
const path = require('path')
const verifyJWT = require('../../middleware/verifyJWT')
const { getAllEmployees,getEmployee,updateEmployee,createEmployee,deleteEmployee} = require('../../controllers/empController')
const verifyRoles= require('../../middleware/verifyRoles')
const ROLES_LIST = require("../../config/roles_list")

employeeRouter.route('/')
       .get(verifyRoles(ROLES_LIST.Admin,ROLES_LIST.Editor,ROLES_LIST.User),getAllEmployees)
       .put(verifyRoles(ROLES_LIST.Admin,ROLES_LIST.Editor),updateEmployee)
       .post(verifyRoles(ROLES_LIST.Admin,ROLES_LIST.Editor),createEmployee)
       .delete(verifyRoles(ROLES_LIST.Admin),deleteEmployee)


 employeeRouter.route('/:id')
       .get(getEmployee)    
module.exports=employeeRouter