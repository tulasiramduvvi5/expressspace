const usersDB={
    users: require("../models/users.json"),
    setUsers : function(data) {this.users = data}
};

const path = require("path");
const fsPromises = require('fs').promises

const handleLogout=async (req,res)=>{
    const cookies = req.cookies;
    if(!cookies?.jwt) res.sendStatus(204);
    const refreshToken = cookies.jwt;
    const foundUser = usersDB.users.find(user=>user.refreshToken===refreshToken)
    if(!foundUser){
        res.clearCookies('jwt',{httpOnly:true,sameSite:'none',secure:true})
        res.sendStatus(204)
    }
    const otherUsers = usersDB.users.filter(person=>person.refreshToken!==refreshToken);
    const currentUser ={...foundUser,refershToken:""}
    usersDB.setUsers([...otherUsers,currentUser])

    await fsPromises.writeFile(
        path.join(__dirname,'..','models','users.json'),
        JSON.stringify(usersDB.users)
    )
}

module.exports = {handleLogout}