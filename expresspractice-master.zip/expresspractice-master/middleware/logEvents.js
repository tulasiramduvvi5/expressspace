const {format} = require('date-fns')
const {v4:uuid} = require('uuid')
const path = require('path')
const fs=require('fs')
const fsPromises = fs.promises
const logEvents = async (msg,fileName)=>{
    const dateTime = format(new Date(),"dd:MM:yy\tHH:mm:ss")
    const logItem = `${dateTime}\t${uuid()}\t${msg}`
    try{
        if(!fs.existsSync(path.join(__dirname,'..','logs')))
            await fsPromises.mkdir(path.join(__dirname,'..','logs'))
        await fsPromises.appendFile(path.join(__dirname,'..','logs',fileName),logItem+"\n")
    }
    catch(error){
        console.log(error.message)
    }
}

const logger = ((req,res,next)=>{
    logEvents(`${req.method}\t${req.headers.origin}\t${req.url}`,'reqLog.txt')
    console.log(req.method,req.url);
    next();
})

module.exports={logEvents,logger};