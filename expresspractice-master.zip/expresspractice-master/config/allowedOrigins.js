const allowedOrigins=["https://www.google.com","http://localhost:5173"]
module.exports = allowedOrigins